package com.example.mysqlexample;


import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.mysqlexample.database.DBHelper;
import com.example.mysqlexample.database.RepairWithVehicle;

import java.util.List;

public class AdapterRepair extends BaseAdapter {

    private Context context;
    private List<RepairWithVehicle> data;

    public AdapterRepair(Context context, List<RepairWithVehicle> dataToBeShown) {
        this.context = context;
        this.data = dataToBeShown;
    }


    //This method grabs the XML elemens and assigns them java variables
    //and then translates the information from a Review object to
    //the layout we want to sue
    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    public View getView(int position, View convertView, ViewGroup container) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.listview_results_row, container, false);
        }

        TextView txtYearMake = convertView.findViewById(R.id.text_year_make_model);
        TextView txtDate = convertView.findViewById(R.id.text_repair_date);
        TextView txtCost = convertView.findViewById(R.id.text_repair_cost);
        TextView txtDescription = convertView.findViewById(R.id.text_repair_description);
        LinearLayout row = convertView.findViewById(R.id.llRow);


        RepairWithVehicle curData = data.get(position);

        //set the year text to   2020 Toyota Camry
        txtYearMake.setText( String.valueOf( curData.getV().getYear()) + " " + curData.getV().getMake());
        txtCost.setText( "$ " + String.valueOf(curData.getR().getCost()));
        txtDescription.setText(curData.getR().getDescription());
        txtDate.setText(curData.getR().getDate());

        row.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                //delete from the database
                DBHelper.getInstance(context).deleteRepairFromRID(curData.getR().getRid());
                data.remove(position);
                notifyDataSetChanged();
                return true;
            }
        });


        return convertView;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return data.get(i);
    }

    //Android made me implement this to cover what a BaseAdapter wants, not sure what goes here?
    @Override
    public long getItemId(int i) {
        return i;
    }


}
