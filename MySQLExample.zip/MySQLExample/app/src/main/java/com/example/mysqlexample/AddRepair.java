package com.example.mysqlexample;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.mysqlexample.database.DBHelper;
import com.example.mysqlexample.database.Repair;
import com.example.mysqlexample.database.Vehicle;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddRepair extends AppCompatActivity {

    Spinner spnVehicles;
    EditText edtDate, edtCost, edtDescr;
    Button btnAddRepair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_repair);

        spnVehicles = findViewById(R.id.spinner_vehicles);
        edtCost = findViewById(R.id.edittext_repair_cost);
        edtDate =findViewById(R.id.edittext_repair_date);
        edtDescr = findViewById(R.id.edittext_repair_description);
        btnAddRepair = findViewById(R.id.button_add_repair);

        //get all the vehicles and then turn them into displayable strings
        //format is  Year Model
        ArrayList<String> displayText = new ArrayList<>();
        List<Vehicle> allVehicles = DBHelper.getInstance(this).getAllVehicles();

        //go through all vehicles and convert them to display string
        for(int i = 0; i < allVehicles.size(); i++){
            Vehicle current = allVehicles.get(i);
            String display = current.getYear() + " " + current.getMake();
            displayText.add(display);
        }

        //use the display strings in an array adapter for the spinner
        ArrayAdapter<String> adp = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,displayText);
        spnVehicles.setAdapter(adp);

        //need a calendar to use the date picker
        Calendar myCalendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                String myFormat="yyyy-mm-dd";
                SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
                edtDate.setText(dateFormat.format(myCalendar.getTime()));
            }
        };
        edtDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(AddRepair.this,date,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });



        btnAddRepair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //grab the info from the screen
                //get the selected vehicle from the spinner
                int idxOfSelection = spnVehicles.getSelectedItemPosition();
                Vehicle selectedVehicle = allVehicles.get(idxOfSelection);

                String costStr = edtCost.getText().toString();
                String date = edtDate.getText().toString();
                String description = edtDescr.getText().toString();

                if (costStr.length() == 0 || date.length() == 0 || description.length() == 0){
                    Toast.makeText(AddRepair.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    double cost = Double.parseDouble(costStr );

                    Repair r = new Repair(date,description,cost,selectedVehicle.getVid());
                    long res = DBHelper.getInstance(AddRepair.this).insertRepair(r);
                    if (res > 0) {
                        Toast.makeText(AddRepair.this, "Success", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(AddRepair.this, "Failed to save new repair", Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });
    }

}