package com.example.mysqlexample;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mysqlexample.database.DBHelper;
import com.example.mysqlexample.database.Vehicle;

public class AddVehicle extends AppCompatActivity {

    EditText edtYear, edtMake, edtPrice;
    CheckBox chkNew;
    Button btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicle);

        edtYear = findViewById(R.id.edittext_year);
        edtMake = findViewById(R.id.edittext_make_model);
        edtPrice = findViewById(R.id.edittext_price);
        chkNew = findViewById(R.id.checkbox_is_new);
        btnAdd = findViewById(R.id.button_add_vehicle);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get all data from the page
                String yearStr = edtYear.getText().toString();
                String make = edtMake.getText().toString();
                String priceStr = edtPrice.getText().toString();

                //if any of these are blank we should not try to add
                if (yearStr.length() == 0 || make.length() == 0 || priceStr.length() == 0 ){
                    Toast.makeText(AddVehicle.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {

                    int year = Integer.parseInt(yearStr);
                    double price = Double.parseDouble(priceStr);
                    boolean isNew = chkNew.isChecked();
                    //at this point we should have all of the information that we need to add a new vehicle
                    Vehicle v = new Vehicle(year, make, price, isNew);
                    DBHelper dbHelper = DBHelper.getInstance(AddVehicle.this);
                    long result = dbHelper.insertVehicle(v);
                    if (result > 0){
                        Toast.makeText(AddVehicle.this, "Success", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(AddVehicle.this, "Failed to save new record", Toast.LENGTH_SHORT).show();
                    }
                }



            }
        });
    }
}