package com.example.mysqlexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.RadioGroup;

import com.example.mysqlexample.database.DBHelper;
import com.example.mysqlexample.database.Repair;
import com.example.mysqlexample.database.RepairWithVehicle;
import com.example.mysqlexample.database.Vehicle;
import com.example.mysqlexample.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private DBHelper db;
    private boolean isVehicles = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        db = DBHelper.getInstance(MainActivity.this);

        binding.radgrp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                if (radioGroup.getCheckedRadioButtonId() == binding.radVehicles.getId()){
                    //vehicle mode
                    showVehicles();
                } else  if (radioGroup.getCheckedRadioButtonId() == binding.radRepairs.getId()){
                    showRepairs();
                }
                isVehicles = !isVehicles;
            }
        });


        binding.btnAddRepair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, AddRepair.class);
                startActivity(i);
            }
        });

        binding.btnAddVehicle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, AddVehicle.class);
                startActivity(i);
            }
        });


    }

    private void showVehicles(){
        ArrayList<Vehicle> allVehicles = db.getAllVehicles();
        ArrayList<String> showData = new ArrayList<>();
        for (int i = 0; i < allVehicles.size(); i++) {
            showData.add(allVehicles.get(i).getMake() + " | " + allVehicles.get(i).getYear() );
        }
        ArrayAdapter<String> adpData = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1,showData);
        binding.lstData.setAdapter(adpData);
    }

    private void showRepairs(){
        ArrayList<RepairWithVehicle> allRepairs = db.getRepairsWithVehicle("");
        AdapterRepair adpData = new AdapterRepair(MainActivity.this,allRepairs);
        binding.lstData.setAdapter(adpData);
    }

    @Override
    protected void onResume() {
        if (isVehicles){
            showVehicles();
        } else {
            showRepairs();
        }
        super.onResume();
    }
}