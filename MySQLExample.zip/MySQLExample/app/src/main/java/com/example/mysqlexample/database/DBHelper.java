package com.example.mysqlexample.database;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {


    private static DBHelper myInstance = null;

    private static final String DB_NAME = "vehicles.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE_VEHICLE_NAME = "vehicles";
    public static final String COL_VEHICLE_VID = "vid";
    public static final String COL_VEHICLE_YEAR = "year";
    public static final String COL_VEHICLE_MAKE = "make";
    public static final String COL_VEHICLE_PRICE= "price";
    public static final String COL_VEHICLE_IS_NEW = "is_new";

    public static final String TABLE_REPAIR_NAME = "repairs";
    public static final String COL_REPAIR_RID = "rid";
    public static final String COL_REPAIR_VID = "vid";
    public static final String COL_REPAIR_DATE = "date";
    public static final String COL_REPAIR_COST = "cost";
    public static final String COL_REPAIR_DESCR = "descr";
    private static Context c;

    public static DBHelper getInstance(Context context){
        //if the helper hasnt been made yet, make it
        if (myInstance == null){
            myInstance = new DBHelper(context);
            c = context;
        }

        return myInstance;
    }


    private DBHelper(@Nullable Context context) {
        //this calls the parent class constructor which in this case is SQLiteOpenHelper
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Create the string to make the table
        //CREATE TABLE *tableName* ( *colName* *variableType*, *colName* *variableType*)
        //use PRIMARY KEY AUTOINCREMENT after the variable that should represent the UNIQUE ID
        //The SQL creates a number for every item added to the table over the lifetime of the app
        //The second item added gets a unique id of 2, if you delete 2 that ID of 2 will never be used again
        String sql = "CREATE TABLE " + TABLE_VEHICLE_NAME + " ("+COL_VEHICLE_VID+" INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_VEHICLE_YEAR + " INTEGER," +
                COL_VEHICLE_MAKE +" TEXT NOT NULL, " +
                COL_VEHICLE_PRICE + " DOUBLE," +
                COL_VEHICLE_IS_NEW + " BOOLEAN ) ";

        db.execSQL(sql);

        //make the repair table
        sql = "CREATE TABLE " + TABLE_REPAIR_NAME + " ("+COL_REPAIR_RID+" INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_REPAIR_COST + " NUMERIC," +
                COL_REPAIR_DATE +" TEXT NOT NULL, " +
                COL_REPAIR_DESCR + " TEXT NOT NULL, " +
                COL_REPAIR_VID + " INTEGER, " +
                "FOREIGN KEY(" + COL_REPAIR_VID +") REFERENCES " + TABLE_VEHICLE_NAME +"("+COL_VEHICLE_VID+"))";

        db.execSQL(sql);
        Toast.makeText(c, "Created new SQL tables!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public Vehicle getVehicleFromVID(int VID){
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + TABLE_VEHICLE_NAME + " WHERE " + COL_VEHICLE_VID + "=" + String.valueOf(VID);
        Cursor c = db.rawQuery(sql,null);

        int idxYear = c.getColumnIndex(COL_VEHICLE_YEAR);
        int idxMake = c.getColumnIndex(COL_VEHICLE_MAKE);
        int idxPrice = c.getColumnIndex(COL_VEHICLE_PRICE);
        int idxNew = c.getColumnIndex(COL_VEHICLE_IS_NEW);
        int idxVID = c.getColumnIndex(COL_VEHICLE_VID);

        Vehicle v = null;

        if (c.moveToFirst()){
                int vid = c.getInt(idxVID);
                int year = c.getInt(idxYear);
                String make = c.getString(idxMake);
                double price = c.getDouble(idxPrice);
                int isNewInt = c.getInt(idxNew);
                boolean isNew;
                if (isNewInt == 1){
                    isNew = true;
                } else {
                    isNew = false;
                }

                v= new Vehicle(year,make,price,isNew, vid );
        }


        return v;
    }

    public Repair getRepairFromRID(int RID){
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + TABLE_REPAIR_NAME + " WHERE " + COL_REPAIR_RID + "=" + String.valueOf(RID);
        Cursor c = db.rawQuery(sql,null);

        ///get repair info
        int idxDate= c.getColumnIndex(COL_REPAIR_DATE);
        int idxCost = c.getColumnIndex(COL_REPAIR_COST);
        int idxDescr = c.getColumnIndex(COL_REPAIR_DESCR);
        int idxVID = c.getColumnIndex(COL_REPAIR_VID);
        int idxRID = c.getColumnIndex(COL_REPAIR_RID);

        Repair r = null;

        if (c.moveToFirst()) {
            //get repair info
            int vid = c.getInt(idxVID);
            int rid = c.getInt(idxRID);
            String descr = c.getString(idxDescr);
            String date = c.getString(idxDate);
            double cost = c.getDouble(idxCost);

            r = new Repair(date, descr, cost, vid, rid);
        }
        return r;
    }

    public long insertVehicle(Vehicle v){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COL_VEHICLE_YEAR,v.getYear());
        cv.put(COL_VEHICLE_MAKE,v.getMake());
        cv.put(COL_VEHICLE_PRICE,v.getPrice());
        cv.put(COL_VEHICLE_IS_NEW,v.isNew());
        //result is the row id after inserting into the table
        long result = db.insert(TABLE_VEHICLE_NAME,null,cv);
        db.close();

        return result;

    }

    public long insertRepair(Repair r){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COL_REPAIR_COST, r.getCost());
        cv.put(COL_REPAIR_DATE, r.getDate());
        cv.put(COL_REPAIR_DESCR, r.getDescription());
        cv.put(COL_REPAIR_VID, r.getVid());

        //result is the row id after inserting into the table
        long result = db.insert(TABLE_REPAIR_NAME,null,cv);
        db.close();

        return result;


    }

    public ArrayList<Vehicle> getAllVehicles(){
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + TABLE_VEHICLE_NAME;
        Cursor c = db.rawQuery(sql,null);

        int idxYear = c.getColumnIndex(COL_VEHICLE_YEAR);
        int idxMake = c.getColumnIndex(COL_VEHICLE_MAKE);
        int idxPrice = c.getColumnIndex(COL_VEHICLE_PRICE);
        int idxNew = c.getColumnIndex(COL_VEHICLE_IS_NEW);
        int idxVID = c.getColumnIndex(COL_VEHICLE_VID);

        ArrayList<Vehicle> allVehicles = new ArrayList<>();

        if (c.moveToFirst()){
            do{
                int vid = c.getInt(idxVID);
                int year = c.getInt(idxYear);
                String make = c.getString(idxMake);
                double price = c.getDouble(idxPrice);
                int isNewInt = c.getInt(idxNew);
                boolean isNew;
                if (isNewInt == 1){
                    isNew = true;
                } else {
                    isNew = false;
                }

                Vehicle newVehicle = new Vehicle(year,make,price,isNew, vid );
                allVehicles.add(newVehicle);

            } while (c.moveToNext());
        }

        db.close();
        return allVehicles;

    }

    public ArrayList<Repair> getAllRepairs(){
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + TABLE_REPAIR_NAME;
        Cursor c = db.rawQuery(sql,null);

        int idxDate= c.getColumnIndex(COL_REPAIR_DATE);
        int idxCost = c.getColumnIndex(COL_REPAIR_COST);
        int idxDescr = c.getColumnIndex(COL_REPAIR_DESCR);
        int idxVID = c.getColumnIndex(COL_REPAIR_VID);
        int idxRID = c.getColumnIndex(COL_REPAIR_RID);

        ArrayList<Repair> allRepairs = new ArrayList<>();

        if (c.moveToFirst()){
            do{
                //get repair info
                int vid = c.getInt(idxVID);
                int rid = c.getInt(idxRID);
                String descr = c.getString(idxDescr);
                String date = c.getString(idxDate);
                double cost = c.getDouble(idxCost);

                Repair r = new Repair(date, descr, cost, vid, rid);
                allRepairs.add(r);

            } while (c.moveToNext());
        }

        db.close();
        return allRepairs;
    }

    //Example of result that joins data from 2 tables
    //This function does not actually return anything just gives an example
    //of the INNER JOIN command
    public ArrayList<RepairWithVehicle> getRepairsWithVehicle(String phrase){

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + TABLE_REPAIR_NAME + " INNER JOIN " + TABLE_VEHICLE_NAME + " ON " +
                TABLE_VEHICLE_NAME + "." + COL_VEHICLE_VID
                + " = " + TABLE_REPAIR_NAME + "." + COL_REPAIR_VID +" WHERE " + COL_REPAIR_DESCR
                +" LIKE '%" + phrase + "%'";
        Cursor c = db.rawQuery(sql,null);

        //INNER JOIN - this will give a result that has as many columns
        //as the data requested so you need to ask for those column ids

        ///get repair info
        int idxDate= c.getColumnIndex(COL_REPAIR_DATE);
        int idxCost = c.getColumnIndex(COL_REPAIR_COST);
        int idxDescr = c.getColumnIndex(COL_REPAIR_DESCR);
        int idxVID = c.getColumnIndex(COL_REPAIR_VID);
        int idxRID = c.getColumnIndex(COL_REPAIR_RID);

        int idxYear = c.getColumnIndex(COL_VEHICLE_YEAR);
        int idxMake = c.getColumnIndex(COL_VEHICLE_MAKE);
        int idxPrice = c.getColumnIndex(COL_VEHICLE_PRICE);
        int idxNew = c.getColumnIndex(COL_VEHICLE_IS_NEW);
        int idxVehicleVID = c.getColumnIndex(COL_VEHICLE_VID);

        ArrayList<RepairWithVehicle> output = new ArrayList<>();

        if (c.moveToFirst()){
            do{

                //get repair info
                int vid = c.getInt(idxVID);
                int rid = c.getInt(idxRID);
                String descr = c.getString(idxDescr);
                String date = c.getString(idxDate);
                double cost = c.getDouble(idxCost);

                Repair r = new Repair(date,descr,cost,vid,rid);

                //get vehicle info

                int year = c.getInt(idxYear);
                String make = c.getString(idxMake);
                double price = c.getDouble(idxPrice);
                int isNewInt = c.getInt(idxNew);
                boolean isNew;
                if (isNewInt == 1){
                    isNew = true;
                } else {
                    isNew = false;
                }

                Vehicle v = new Vehicle(year,make,price,isNew, vid );
                RepairWithVehicle rPV = new RepairWithVehicle(r,v);
                output.add(rPV);


            } while (c.moveToNext());
        }

        db.close();

        return output;

    }

    public String deleteRepairFromRID(int rid){
        SQLiteDatabase db = getWritableDatabase();
        String where = COL_REPAIR_RID + "id=" + String.valueOf(rid);
        db.delete(TABLE_REPAIR_NAME,where , null);
        db.close();
        return where;
    }

    public String deleteVehicleFromVID(int vid){
        SQLiteDatabase db = getWritableDatabase();
        String where = COL_REPAIR_VID + "=" + String.valueOf(vid);
        db.delete(TABLE_VEHICLE_NAME,where , null);
        db.close();
        return where;
    }
}
