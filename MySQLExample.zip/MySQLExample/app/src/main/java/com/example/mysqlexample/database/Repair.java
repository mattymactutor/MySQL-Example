package com.example.mysqlexample.database;

public class Repair {

    private String date;
    private String description;
    private double cost;
    private int rid;
    private int vid;

    public Repair() {

    }

    public Repair(String date, String description, double cost, int vid) {
        this.date = date;
        this.description = description;
        this.cost = cost;
        this.vid = vid;
    }

    public Repair(String date, String description, double cost, int vid, int rid) {
        this.date = date;
        this.description = description;
        this.cost = cost;
        this.vid = vid;
        this.rid = rid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public int getVid() {
        return vid;
    }

    public void setVid(int vid) {
        this.vid = vid;
    }

    public int getRid() {
        return rid;
    }

    public void setRid(int rid) {
        this.rid = rid;
    }
}
