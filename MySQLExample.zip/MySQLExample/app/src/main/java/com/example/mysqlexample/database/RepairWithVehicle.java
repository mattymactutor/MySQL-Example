package com.example.mysqlexample.database;

public class RepairWithVehicle {

    private Repair r;
    private Vehicle v;

    public RepairWithVehicle() {

    }

    public RepairWithVehicle(Repair r, Vehicle v) {
        this.r = r;
        this.v = v;
    }

    public Repair getR() {
        return r;
    }


    public Vehicle getV() {
        return v;
    }


}
