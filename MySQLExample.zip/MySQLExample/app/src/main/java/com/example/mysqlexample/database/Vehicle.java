package com.example.mysqlexample.database;

public class Vehicle {

    private int year;
    private String make;
    private double price;
    private boolean isNew;
    private int vid;

    public Vehicle() {

    }

    public Vehicle(int year, String make, double price, boolean isNew) {
        this.year = year;
        this.make = make;
        this.price = price;
        this.isNew = isNew;
    }

    public Vehicle(int year, String make, double price, boolean isNew, int vid) {
        this.year = year;
        this.make = make;
        this.price = price;
        this.isNew = isNew;
        this.vid = vid;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isNew() {
        return isNew;
    }

    public void setNew(boolean aNew) {
        isNew = aNew;
    }

    public int getVid() {
        return vid;
    }

    public void setVid(int vid) {
        this.vid = vid;
    }
}
